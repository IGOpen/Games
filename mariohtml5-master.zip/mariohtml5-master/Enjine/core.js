/**
	Define the Enjine namespace and any other miscellaneous setup.
	Code by Rob Kleffner, 2011
*/

var Enjine = {};